from flask import Flask, render_template, request, redirect, url_for
import cv2
import numpy as np
import matplotlib.pyplot as plt

app = Flask(__name__)

def preprocess_image(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (11, 11), 0)
    return blur

def detect_objects(image):
    canny = cv2.Canny(image, 30, 150)
    dilated = cv2.dilate(canny, (3, 3), iterations=2)
    (contours, _) = cv2.findContours(dilated.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    return contours

def filter_objects(contours, min_area=100):
    filtered_contours = []
    for contour in contours:
        area = cv2.contourArea(contour)
        if area > min_area:
            filtered_contours.append(contour)
    return filtered_contours

def draw_contours(image, contours):
    for contour in contours:
        cv2.drawContours(image, [contour], -1, (0, 255, 0), 2)
    return image

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        
        file = request.files['file']
        
        if file.filename == '':
            return redirect(request.url)
        
        if file:
            image = cv2.imdecode(np.fromstring(file.read(), np.uint8), cv2.IMREAD_UNCHANGED)
            processed_image = preprocess_image(image)
            contours = detect_objects(processed_image)
            filtered_contours = filter_objects(contours)

            # Draw contours on the original image
            result_image = draw_contours(image.copy(), filtered_contours)

            # Save the processed image temporarily
            plt.imsave('static/result.jpg', cv2.cvtColor(result_image, cv2.COLOR_BGR2RGB))

            objects_count = len(filtered_contours)
            return render_template('result.html', objects_count=objects_count)

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
